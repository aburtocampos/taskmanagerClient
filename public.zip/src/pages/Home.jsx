import React from 'react';
import TaskList from '../components/TaskList';
import LogoutButton from '../components/LogoutButton';

const Home = () => {
  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Lista de Tareas</h1>
        <LogoutButton />
      </div>
      <TaskList />
    </div>
  );
};

export default Home;
