import React from 'react';
import useAuth from '../hooks/useAuth';

const LogoutButton = () => {
  const { handleLogout } = useAuth();

  return (
    <button
      onClick={handleLogout}
      className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
    >
      Cerrar Sesión
    </button>
  );
};

export default LogoutButton;
