import React from 'react';
import useTasks from '../hooks/useTasks';

const TaskList = () => {
  const { tasks, removeTask, editTask } = useTasks();

  const toggleStatus = task => {
    editTask(task.id, { ...task, status: !task.status });
  };

  return (
    <div className="space-y-4">
      {tasks.map(task => (
        <div
          key={task.id}
          className="p-4 border border-gray-300 rounded-md shadow-sm bg-white"
        >
          <h3 className="text-lg font-bold">{task.title}</h3>
          <p>{task.status ? 'Completada' : 'Pendiente'}</p>
          <p className="text-sm text-gray-500">
            Creada el: {new Date(task.createdAt).toLocaleString()}
          </p>
          <div className="flex space-x-4 mt-2">
            <button
              onClick={() => toggleStatus(task)}
              className="px-4 py-2 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              {task.status ? 'Marcar como Pendiente' : 'Marcar como Completada'}
            </button>
            <button
              onClick={() => removeTask(task.id)}
              className="px-4 py-2 text-sm bg-red-500 text-white rounded hover:bg-red-600"
            >
              Eliminar
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TaskList;
