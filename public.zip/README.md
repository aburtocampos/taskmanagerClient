## DEMO
The Swagger Docmunetation of the endpoitns is live on 
https://taskmanager-1-2y65.onrender.com/api-docs/

App on React can be find on:
https://ramontaskmanager.netlify.app/